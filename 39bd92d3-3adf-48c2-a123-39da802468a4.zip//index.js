import {
  Project,
  Sprite,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import _1 from "./_1/_1.js";
import _3 from "./_3/_3.js";
import _4 from "./_4/_4.js";
import _2 from "./_2/_2.js";
import Turn from "./Turn/Turn.js";
import Dark from "./Dark/Dark.js";
import _5 from "./_5/_5.js";
import TheBoard from "./TheBoard/TheBoard.js";
import Drawer1 from "./Drawer1/Drawer1.js";
import Drawer2 from "./Drawer2/Drawer2.js";
import Drawer3 from "./Drawer3/Drawer3.js";
import Drawer4 from "./Drawer4/Drawer4.js";
import Drawer5ThisOne from "./Drawer5ThisOne/Drawer5ThisOne.js";
import Drawer5ThisOne2 from "./Drawer5ThisOne2/Drawer5ThisOne2.js";
import FolderChoice from "./FolderChoice/FolderChoice.js";
import FolderClose from "./FolderClose/FolderClose.js";
import FolderChoice2 from "./FolderChoice2/FolderChoice2.js";
import Folder1Close from "./Folder1Close/Folder1Close.js";
import Folder1 from "./Folder1/Folder1.js";
import Folder2 from "./Folder2/Folder2.js";
import Folder3 from "./Folder3/Folder3.js";
import FolderChoice3 from "./FolderChoice3/FolderChoice3.js";
import Folder2Close from "./Folder2Close/Folder2Close.js";
import Welcome from "./Welcome/Welcome.js";
import Drawer5 from "./Drawer5/Drawer5.js";
import Drawer6 from "./Drawer6/Drawer6.js";
import Drawer7 from "./Drawer7/Drawer7.js";

const stage = new Stage({ costumeNumber: 4 });

const sprites = {
  _1: new _1({
    x: 2,
    y: -55,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 2,
  }),
  _3: new _3({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 110.00000000000001,
    visible: true,
    layerOrder: 1,
  }),
  _4: new _4({
    x: -101,
    y: -19,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 75,
    visible: true,
    layerOrder: 6,
  }),
  _2: new _2({
    x: -102,
    y: -18,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 75,
    visible: true,
    layerOrder: 4,
  }),
  Turn: new Turn({
    x: 206,
    y: -155,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 8,
  }),
  Dark: new Dark({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 120,
    visible: true,
    layerOrder: 7,
  }),
  _5: new _5({
    x: -177,
    y: -83,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 5,
  }),
  TheBoard: new TheBoard({
    x: -85,
    y: 32,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 3,
  }),
  Drawer1: new Drawer1({
    x: -114,
    y: -7,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 10,
  }),
  Drawer2: new Drawer2({
    x: -113.97175143876174,
    y: -39.70501539295168,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 11,
  }),
  Drawer3: new Drawer3({
    x: -113.59982202262329,
    y: -72.17700606051454,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 12,
  }),
  Drawer4: new Drawer4({
    x: -113.5109940889292,
    y: -115.21732644836146,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 13,
  }),
  Drawer5ThisOne: new Drawer5ThisOne({
    x: -114.43751533076514,
    y: -147.7969526116565,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 22,
  }),
  Drawer5ThisOne2: new Drawer5ThisOne2({
    x: -114,
    y: -148,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 21,
  }),
  FolderChoice: new FolderChoice({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 75,
    visible: false,
    layerOrder: 16,
  }),
  FolderClose: new FolderClose({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 75,
    visible: false,
    layerOrder: 20,
  }),
  FolderChoice2: new FolderChoice2({
    x: 431,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 15,
  }),
  Folder1Close: new Folder1Close({
    x: 35.4222067649047,
    y: 74.80035820643745,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 105,
    visible: false,
    layerOrder: 23,
  }),
  Folder1: new Folder1({
    x: 0,
    y: -0.4688068664240763,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 75,
    visible: false,
    layerOrder: 19,
  }),
  Folder2: new Folder2({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 75,
    visible: false,
    layerOrder: 18,
  }),
  Folder3: new Folder3({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 75,
    visible: false,
    layerOrder: 17,
  }),
  FolderChoice3: new FolderChoice3({
    x: 417,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 14,
  }),
  Folder2Close: new Folder2Close({
    x: 41.33452306090865,
    y: 80.86404279225289,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 105,
    visible: false,
    layerOrder: 24,
  }),
  Welcome: new Welcome({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 110.00000000000001,
    visible: true,
    layerOrder: 9,
  }),
  Drawer5: new Drawer5({
    x: -198,
    y: -5,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 25,
  }),
  Drawer6: new Drawer6({
    x: -197.68722753168984,
    y: -38.66713472286634,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 26,
  }),
  Drawer7: new Drawer7({
    x: -197.55213367427748,
    y: -72.33484659685423,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 27,
  }),
};

const project = new Project(stage, sprites, {
  frameRate: 30, // Set to 60 to make your project run faster
});
export default project;
