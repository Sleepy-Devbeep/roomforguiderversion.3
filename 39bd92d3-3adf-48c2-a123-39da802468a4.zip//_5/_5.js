/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class _5 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./_5/costumes/1.svg", { x: 60.811375, y: 102.237695 }),
      new Costume("2", "./_5/costumes/2.svg", {
        x: 60.81137500000003,
        y: 102.23769594495025,
      }),
    ];

    this.sounds = [
      new Sound("Bonk", "./_5/sounds/Bonk.wav"),
      new Sound(
        "drawer-open-mid-84663",
        "./_5/sounds/drawer-open-mid-84663.mp3"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(-177, -83);
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 2) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.goto(-177, -83);
    while (true) {
      if (this.toNumber(this.stage.vars.folder) === 1) {
        this.costume = 2;
      } else {
        this.costume = 1;
      }
      yield;
    }
  }
}
