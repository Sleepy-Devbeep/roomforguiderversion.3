/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Drawer7 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Drawer7/costumes/1.svg", {
        x: 36.78936781249999,
        y: 13.70895320516243,
      }),
    ];

    this.sounds = [new Sound("lock-36695", "./Drawer7/sounds/lock-36695.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.ghost = 99;
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 2) {
        this.visible = true;
      }
      if (this.toNumber(this.stage.vars.roomside1) === 1) {
        this.visible = false;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    yield* this.startSound("lock-36695");
    yield* this.thinkAndWait(
      '"Something tells you that you shouldn\'t open it..." though it is still locked.',
      4
    );
  }
}
