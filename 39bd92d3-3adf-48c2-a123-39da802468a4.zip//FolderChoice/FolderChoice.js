/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class FolderChoice extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./FolderChoice/costumes/1.svg", {
        x: 196.696675,
        y: 95.88963999999996,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Choice" },
        this.whenIReceiveChoice
      ),
      new Trigger(Trigger.BROADCAST, { name: "Hide" }, this.whenIReceiveHide),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.folder = 0;
  }

  *whenIReceiveChoice() {
    this.visible = true;
  }

  *whenIReceiveHide() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.visible = false;
    this.stage.vars.folder = 0;
    while (true) {
      if (this.toNumber(this.stage.vars.folder1) === 1) {
        this.visible = false;
      }
      if (this.toNumber(this.stage.vars.folder2) === 1) {
        this.visible = false;
      }
      yield;
    }
  }
}
