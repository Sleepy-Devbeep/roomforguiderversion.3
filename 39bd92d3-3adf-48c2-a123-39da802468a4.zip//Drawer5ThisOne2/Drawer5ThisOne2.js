/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Drawer5ThisOne2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Drawer5ThisOne2/costumes/1.svg", {
        x: 36.78936781249999,
        y: 13.708963205162433,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.folder = 0;
    this.effects.ghost = 99;
    while (true) {
      if (this.toNumber(this.stage.vars.folder) === 1) {
        this.visible = true;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    this.broadcast("Choice");
    this.visible = false;
  }
}
