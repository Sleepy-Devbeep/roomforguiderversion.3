/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class FolderChoice3 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("6", "./FolderChoice3/costumes/6.svg", {
        x: 192.274135,
        y: 144.63885,
      }),
    ];

    this.sounds = [
      new Sound(
        "crumping-paper-109585",
        "./FolderChoice3/sounds/crumping-paper-109585.mp3"
      ),
      new Sound(
        "mixkit-paper-slide-1530",
        "./FolderChoice3/sounds/mixkit-paper-slide-1530.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Close Folder2" },
        this.whenIReceiveCloseFolder2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Folder2" },
        this.whenIReceiveFolder2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(431, 0);
    this.visible = false;
    this.stage.vars.folder2 = 0;
    this.costume = 1;
    while (true) {
      if (this.toNumber(this.stage.vars.folder2) === 1) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenIReceiveCloseFolder2() {
    this.costume = 1;
    this.goto(431, 0);
  }

  *whenIReceiveFolder2() {
    yield* this.startSound("mixkit-paper-slide-1530");
    for (let i = 0; i < 1; i++) {
      if (this.toNumber(this.stage.vars.folder2) === 1) {
        this.stage.vars.target = 0;
        while (
          !(
            this.compare(
              Math.abs(this.x - this.toNumber(this.stage.vars.target)),
              0.1
            ) < 0
          )
        ) {
          this.x = (this.x - this.toNumber(this.stage.vars.target)) / 1.1;
          yield;
        }
      }
      yield;
    }
  }
}
