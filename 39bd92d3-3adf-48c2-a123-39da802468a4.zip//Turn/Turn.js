/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Turn extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("balloon1-c", "./Turn/costumes/balloon1-c.svg", {
        x: 24.44986838952468,
        y: 15.201837070279197,
      }),
    ];

    this.sounds = [
      new Sound("Pop", "./Turn/sounds/Pop.wav"),
      new Sound("Low Whoosh", "./Turn/sounds/Low Whoosh.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.roomside1 = 1;
    while (true) {
      if (this.touching("mouse")) {
        this.size = 110;
        this.effects.brightness = 10;
      } else {
        this.size = 100;
        this.effects.brightness = 0;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 3) {
        this.stage.vars.roomside1 = 1;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    this.stage.vars.roomside1++;
    yield* this.startSound("Low Whoosh");
  }
}
