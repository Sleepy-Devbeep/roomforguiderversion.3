/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Drawer5ThisOne extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Drawer5ThisOne/costumes/1.svg", {
        x: 36.78936781249999,
        y: 13.70895320516243,
      }),
    ];

    this.sounds = [
      new Sound(
        "drawer-open-mid-84663",
        "./Drawer5ThisOne/sounds/drawer-open-mid-84663.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.folder = 0;
    this.effects.ghost = 99;
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 2) {
        this.visible = true;
      }
      if (this.toNumber(this.stage.vars.roomside1) === 1) {
        this.visible = false;
      }
      if (this.toNumber(this.stage.vars.folder) === 1) {
        this.visible = false;
        return;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    yield* this.startSound("drawer-open-mid-84663");
    this.stage.vars.folder = 1;
    this.visible = false;
  }
}
