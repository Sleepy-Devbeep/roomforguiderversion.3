/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Welcome extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Welcome/costumes/1.svg", {
        x: 291.2912912912913,
        y: 211.71171171171167,
      }),
    ];

    this.sounds = [
      new Sound(
        "lights-flicker-on-and-some-electrical-noises-33079",
        "./Welcome/sounds/lights-flicker-on-and-some-electrical-noises-33079.wav"
      ),
      new Sound(
        "lights-flicker-on-and-some-electrical-noises-2",
        "./Welcome/sounds/lights-flicker-on-and-some-electrical-noises-2.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Stillhere?" },
        this.whenIReceiveStillhere
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.ghost = 10;
    this.visible = true;
    this.goto(0, 0);
    for (let i = 0; i < 1; i++) {
      yield* this.wait(1.5);
      this.effects.ghost = 100;
      yield* this.wait(0.01);
      this.effects.ghost = 10;
      yield* this.wait(0.01);
      this.effects.ghost = 100;
      yield* this.wait(0.5);
      this.effects.ghost = 100;
      yield;
    }
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    yield* this.wait(0.1);
    while (true) {
      yield* this.playSoundUntilDone(
        "lights-flicker-on-and-some-electrical-noises-33079"
      );
      this.broadcast("Stillhere?");
      return;
      yield;
    }
  }

  *whenIReceiveStillhere() {
    while (true) {
      yield* this.playSoundUntilDone(
        "lights-flicker-on-and-some-electrical-noises-2"
      );
      yield;
    }
  }
}
