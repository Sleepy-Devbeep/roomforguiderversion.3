/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Dark extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("...", "./Dark/costumes/....svg", {
        x: 251.2929618150293,
        y: 180.9309317417417,
      }),
      new Costume("...2", "./Dark/costumes/...2.svg", {
        x: 271.771745,
        y: 193.693685,
      }),
    ];

    this.sounds = [
      new Sound("Boing", "./Dark/sounds/Boing.wav"),
      new Sound("Pop", "./Dark/sounds/Pop.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.visible = true;
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 1) {
        this.costume = "...";
      }
      if (this.toNumber(this.stage.vars.roomside1) === 2) {
        this.costume = "...2";
      }
      yield;
    }
  }
}
