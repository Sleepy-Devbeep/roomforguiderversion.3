/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class FolderChoice2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./FolderChoice2/costumes/1.svg", {
        x: 206.220665,
        y: 140.91044,
      }),
      new Costume("2", "./FolderChoice2/costumes/2.svg", {
        x: 215.97162,
        y: 155.790095,
      }),
      new Costume("3", "./FolderChoice2/costumes/3.svg", {
        x: 224.827135,
        y: 155.790095,
      }),
      new Costume("4", "./FolderChoice2/costumes/4.svg", {
        x: 219.94024,
        y: 155.790095,
      }),
      new Costume("5", "./FolderChoice2/costumes/5.svg", {
        x: 228.05771,
        y: 155.790095,
      }),
      new Costume("6", "./FolderChoice2/costumes/6.svg", {
        x: 226.3192203238806,
        y: 155.790095,
      }),
      new Costume("7", "./FolderChoice2/costumes/7.svg", {
        x: 206.220665,
        y: 140.91044,
      }),
    ];

    this.sounds = [
      new Sound("Low Whoosh", "./FolderChoice2/sounds/Low Whoosh.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Closed Folder1" },
        this.whenIReceiveClosedFolder1
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Folder1" },
        this.whenIReceiveFolder1
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(431, 0);
    this.visible = false;
    this.stage.vars.folder1 = 0;
    this.costume = 1;
    while (true) {
      if (this.toNumber(this.stage.vars.folder1) === 1) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {}

  *whenthisspriteclicked() {
    this.costumeNumber++;
  }

  *whenIReceiveClosedFolder1() {
    yield* this.startSound("Low Whoosh");
    this.costume = 1;
    this.goto(431, 0);
  }

  *whenIReceiveFolder1() {
    for (let i = 0; i < 1; i++) {
      if (this.toNumber(this.stage.vars.folder1) === 1) {
        this.stage.vars.target = 0;
        while (
          !(
            this.compare(
              Math.abs(this.x - this.toNumber(this.stage.vars.target)),
              0.1
            ) < 0
          )
        ) {
          this.x = (this.x - this.toNumber(this.stage.vars.target)) / 1.3;
          yield;
        }
      }
      yield;
    }
  }
}
