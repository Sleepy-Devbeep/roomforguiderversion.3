/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class FolderClose extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./FolderClose/costumes/1.svg", {
        x: -147.5,
        y: 79.58181818181819,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Choice" },
        this.whenIReceiveChoice
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.folder = 0;
    while (true) {
      if (this.toNumber(this.stage.vars.folder1) === 1) {
        this.visible = false;
      }
      if (this.toNumber(this.stage.vars.folder2) === 1) {
        this.visible = false;
      }
      yield;
    }
  }

  *whenIReceiveChoice() {
    this.visible = true;
  }

  *whenthisspriteclicked() {
    this.broadcast("Hide");
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.visible = false;
    this.stage.vars.folder = 0;
  }
}
