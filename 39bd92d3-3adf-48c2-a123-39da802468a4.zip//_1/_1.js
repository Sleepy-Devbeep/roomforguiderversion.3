/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class _1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./_1/costumes/1.svg", {
        x: 265.501445,
        y: 256.7506850000001,
      }),
      new Costume("2", "./_1/costumes/2.svg", { x: 265.501435, y: 256.750675 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 1) {
        this.visible = true;
      }
      if (this.toNumber(this.stage.vars.roomside1) === 2) {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      yield* this.wait(0.01);
      this.costumeNumber++;
      yield;
    }
  }
}
