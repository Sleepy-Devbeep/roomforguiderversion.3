/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Folder1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Folder1/costumes/1.svg", {
        x: 176.99998499999998,
        y: 43.25,
      }),
    ];

    this.sounds = [
      new Sound("High Whoosh", "./Folder1/sounds/High Whoosh.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Choice" },
        this.whenIReceiveChoice
      ),
      new Trigger(Trigger.BROADCAST, { name: "Hide" }, this.whenIReceiveHide),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.folder1 = 0;
    while (true) {
      if (this.toNumber(this.stage.vars.folder1) === 1) {
        this.visible = false;
      }
      if (this.toNumber(this.stage.vars.folder2) === 1) {
        this.visible = false;
      }
      yield;
    }
  }

  *whenIReceiveChoice() {
    this.visible = true;
  }

  *whenIReceiveHide() {
    this.visible = false;
  }

  *whenthisspriteclicked() {
    yield* this.startSound("High Whoosh");
    this.broadcast("Folder1");
    this.stage.vars.folder1 = 1;
  }
}
