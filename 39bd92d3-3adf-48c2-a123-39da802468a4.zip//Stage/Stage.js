/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 167.2093638230131,
        y: 2.4189366541396,
      }),
      new Costume("costume2", "./Stage/costumes/costume2.svg", {
        x: 209.22838942131892,
        y: 153.041855,
      }),
      new Costume("costume4", "./Stage/costumes/costume4.svg", {
        x: 70.99994500000003,
        y: 115.83635820061039,
      }),
      new Costume("costume3", "./Stage/costumes/costume3.svg", {
        x: 70.5,
        y: 5.086630464076251,
      }),
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.roomside1 = 1;
    this.vars.folder = 0;
    this.vars.folder1 = 0;
    this.vars.target = 0;
    this.vars.folder2 = 0;
  }
}
