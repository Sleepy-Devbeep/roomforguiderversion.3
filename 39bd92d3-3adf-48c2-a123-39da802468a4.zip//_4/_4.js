/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class _4 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./_4/costumes/1.svg", {
        x: 75.30283499999999,
        y: -2.7558745648703677,
      }),
      new Costume("2", "./_4/costumes/2.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [new Sound("Bonk", "./_4/sounds/Bonk.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      yield* this.wait(this.random(1, 4));
      this.costume = 1;
      yield* this.wait(this.random(0.01, 0.03));
      this.costume = 2;
      yield* this.wait(this.random(0.01, 0.05));
      this.costume = 1;
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 1) {
        this.visible = true;
      }
      if (this.toNumber(this.stage.vars.roomside1) === 2) {
        this.visible = false;
      }
      yield;
    }
  }
}
