/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class TheBoard extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("...", "./TheBoard/costumes/....svg", {
        x: 140.9925,
        y: 98.80904500000003,
      }),
    ];

    this.sounds = [
      new Sound("Boing", "./TheBoard/sounds/Boing.wav"),
      new Sound("Pop", "./TheBoard/sounds/Pop.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.toNumber(this.stage.vars.roomside1) === 1) {
        this.visible = true;
      }
      if (this.toNumber(this.stage.vars.roomside1) === 2) {
        this.visible = false;
      }
      yield;
    }
  }
}
